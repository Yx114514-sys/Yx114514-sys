// pages/message/index.js
Page({
tochat(){
  wx.navigateTo({
    url: '/pages/chat/index' // 确保这个路径是你的帖子详细页面的路径
  });
}
})