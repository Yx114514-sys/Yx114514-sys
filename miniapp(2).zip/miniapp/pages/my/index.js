Page({
    
  
  toid: function(){
    wx.navigateTo({
      url: '/pages/id/index' // 确保这个路径是你的帖子详细页面的路径
    });
  }



});